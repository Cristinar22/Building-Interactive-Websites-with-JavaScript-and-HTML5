function calculateTotal(price, quantity) {
  let total = price * quantity;
  console.log('Total:', total);
  return total;
}

calculateTotal(5, 3);
