form.addEventListener('submit', function(event) {
  event.preventDefault();

  if (nameInput.value.trim() === '') {
    error.textContent = 'Name is required.';
    return;
  }

  if (!emailInput.value.includes('@')) {
    error.textContent = 'Enter a valid email.';
    return;
  }

  error.textContent = '';
  alert('Form submitted!');
});
