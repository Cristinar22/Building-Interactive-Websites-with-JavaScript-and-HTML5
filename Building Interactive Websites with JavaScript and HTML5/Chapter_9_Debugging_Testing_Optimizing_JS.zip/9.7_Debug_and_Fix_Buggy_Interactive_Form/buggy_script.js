const form = document.getElementById('contactForm');
const nameInput = document.getElementById('name');
const emailInput = document.getElementById('email');
const error = document.getElementById('error');

form.addEventListener('submit', function() {
  if (nameInput.value = '') {
    error.textContent = 'Name is required.';
    return;
  }
  if (!emailInput.value.includes('@')) {
    error.textContent = 'Enter a valid email.';
    return;
  }
  error.textContent = '';
  alert('Form submitted!');
});
