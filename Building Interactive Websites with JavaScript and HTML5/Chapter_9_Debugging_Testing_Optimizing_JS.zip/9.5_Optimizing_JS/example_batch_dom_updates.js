const list = document.getElementById('list');
const fragment = document.createDocumentFragment();

for(let i=0; i<100; i++) {
  const li = document.createElement('li');
  li.textContent = `Item ${i+1}`;
  fragment.appendChild(li);
}

list.appendChild(fragment);
