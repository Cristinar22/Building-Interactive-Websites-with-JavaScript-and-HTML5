function greet(name = "Guest") {
  console.log("Hello, " + name);
}

greet();
