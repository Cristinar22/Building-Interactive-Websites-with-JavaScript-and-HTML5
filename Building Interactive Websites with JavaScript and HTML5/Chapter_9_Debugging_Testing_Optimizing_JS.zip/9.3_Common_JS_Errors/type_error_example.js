let num = 5;
num.toUpperCase();  // Error! Number doesn’t have toUpperCase method
