function multiply(a, b) {
  return a * b;
}

console.log(multiply(2, 3));  // Should be 6
console.log(multiply(0, 5));  // Should be 0
console.log(multiply(-1, 4)); // Should be -4
