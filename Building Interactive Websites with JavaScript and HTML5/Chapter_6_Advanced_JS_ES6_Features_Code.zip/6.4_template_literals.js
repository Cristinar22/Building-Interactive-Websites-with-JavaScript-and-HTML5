// 6.4 Template Literals: Embedding Variables in Strings
let name = "Alice";
console.log(`Hello, ${name}!`);

// Hands-On Example 3:
let item = "book";
let price = 15;

console.log(`The price of the ${item} is $${price}.`);
