// 6.5 Destructuring Assignment

// Destructuring Arrays
const [first, second] = [1, 2, 3];
console.log(first, second);  // 1 2

// Destructuring Objects
const { name, age } = { name: "Alice", age: 30 };
console.log(name, age);  // Alice 30

// Hands-On Example 4:
const user = {
  username: "johndoe",
  email: "john@example.com",
  role: "admin"
};

const { username, email } = user;
console.log(`User: ${username}, Email: ${email}`);
