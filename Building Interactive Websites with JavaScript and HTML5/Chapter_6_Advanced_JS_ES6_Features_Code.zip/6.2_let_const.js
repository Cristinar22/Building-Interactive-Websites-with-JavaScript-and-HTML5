// 6.2 Better Variable Declarations: let and const
let age = 25;
age = 26;  // Works fine

const name = "Alice";
name = "Bob";  // Error! You cannot change a const variable

// Hands-On Example 1
if (true) {
  let x = 10;
  const y = 20;
  console.log(x);  // 10
  console.log(y);  // 20
}

// console.log(x);  // Uncaught ReferenceError
// console.log(y);  // Uncaught ReferenceError
