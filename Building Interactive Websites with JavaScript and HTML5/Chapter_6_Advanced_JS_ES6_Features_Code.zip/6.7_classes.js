// 6.7 Classes: Basic Object-Oriented Programming

class Person {
  constructor(name, age) {
    this.name = name;
    this.age = age;
  }

  greet() {
    return `Hi, I'm ${this.name} and I'm ${this.age} years old.`;
  }
}

const alice = new Person("Alice", 25);
console.log(alice.greet());

// Hands-On Example 6:
class Car {
  constructor(make, model) {
    this.make = make;
    this.model = model;
  }

  info() {
    return `Car: ${this.make} ${this.model}`;
  }
}

const myCar = new Car("Toyota", "Corolla");
console.log(myCar.info());
