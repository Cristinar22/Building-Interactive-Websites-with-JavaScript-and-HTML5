// 6.12 Refactor Existing Code: Use Arrow Functions and Template Literals

// Old style:
function greet(name) {
  return "Hello, " + name + "!";
}

// New style:
const greet = name => `Hello, ${name}!`;
