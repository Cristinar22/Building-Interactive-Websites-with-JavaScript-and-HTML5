// 6.8 Modules: Exporting (math.js)
export function add(a, b) {
  return a + b;
}
