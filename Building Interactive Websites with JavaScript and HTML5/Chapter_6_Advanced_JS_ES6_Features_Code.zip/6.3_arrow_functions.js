// 6.3 Arrow Functions: Simpler Functions
// Traditional Function:
function greet(name) {
  return "Hello, " + name + "!";
}

// Arrow Function Equivalent:
const greet = (name) => {
  return `Hello, ${name}!`;
}

// Shortened if single return statement:
const greetShort = name => `Hello, ${name}!`;

// Hands-On Example 2:
function add(a, b) {
  return a + b;
}
console.log(add(3, 4));  // 7

const addArrow = (a, b) => a + b;
console.log(addArrow(3, 4));  // 7
