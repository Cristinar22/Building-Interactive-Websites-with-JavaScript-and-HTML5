// 6.8 Modules: Importing (script.js)
import { add } from './math.js';

console.log(add(5, 3));
