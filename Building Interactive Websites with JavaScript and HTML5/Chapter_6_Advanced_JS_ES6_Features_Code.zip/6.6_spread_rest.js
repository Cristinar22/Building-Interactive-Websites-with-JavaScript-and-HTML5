// 6.6 Spread and Rest Operators

// Spread Operator (...)
const arr1 = [1, 2];
const arr2 = [...arr1, 3, 4];
console.log(arr2);  // [1, 2, 3, 4]

// Rest Operator (...)
function sum(...numbers) {
  return numbers.reduce((a, b) => a + b, 0);
}

console.log(sum(1, 2, 3));  // 6

// Hands-On Example 5:
const arr = [5, 6, 7];
const newArr = [1, 2, 3, ...arr];
console.log(newArr);  // [1, 2, 3, 5, 6, 7]

function multiply(multiplier, ...args) {
  return args.map(x => x * multiplier);
}

console.log(multiply(2, 1, 2, 3));  // [2, 4, 6]
