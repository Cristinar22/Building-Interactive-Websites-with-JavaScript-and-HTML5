// 6.11 Hands-On Project: Display Data from JSON File

async function displayBooks() {
  const response = await fetch('data.json');
  const books = await response.json();

  const container = document.getElementById('bookList');
  books.forEach(book => {
    container.innerHTML += `<p><strong>${book.title}</strong> by ${book.author}</p>`;
  });
}

displayBooks();
