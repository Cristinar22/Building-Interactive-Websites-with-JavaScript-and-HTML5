// 6.9 Asynchronous Programming: Promises and async/await

const promise = new Promise((resolve, reject) => {
  setTimeout(() => resolve("Success!"), 2000);
});

promise.then(result => console.log(result));  // Logs "Success!" after 2 seconds

async function fetchData() {
  const result = await promise;
  console.log(result);
}

fetchData();

// Hands-On Example 7:
async function loadUsers() {
  const response = await fetch('data.json');
  const users = await response.json();

  users.forEach(user => {
    const p = document.createElement('p');
    p.textContent = `User: ${user.name} (ID: ${user.id})`;
    document.body.appendChild(p);
  });
}

loadUsers();
