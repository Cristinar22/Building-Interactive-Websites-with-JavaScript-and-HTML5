const taskForm = document.getElementById('taskForm');
const taskInput = document.getElementById('taskInput');
const taskList = document.getElementById('taskList');
const errorMsg = document.getElementById('errorMsg');

taskForm.addEventListener('submit', function(e) {
  e.preventDefault();

  const taskText = taskInput.value.trim();

  if (taskText === "") {
    errorMsg.textContent = "Task cannot be empty!";
    return;
  }

  errorMsg.textContent = "";

  const li = document.createElement('li');

  const taskSpan = document.createElement('span');
  taskSpan.textContent = taskText;
  li.appendChild(taskSpan);

  const completeBtn = document.createElement('button');
  completeBtn.textContent = "Complete";
  completeBtn.className = "completeBtn";
  li.appendChild(completeBtn);

  const deleteBtn = document.createElement('button');
  deleteBtn.textContent = "Delete";
  deleteBtn.className = "deleteBtn";
  li.appendChild(deleteBtn);

  taskList.appendChild(li);
  taskInput.value = "";
});

taskList.addEventListener('click', function(e) {
  if (e.target.classList.contains('completeBtn')) {
    const task = e.target.previousSibling;
    task.classList.toggle('completed');
  }

  if (e.target.classList.contains('deleteBtn')) {
    const li = e.target.parentElement;
    taskList.removeChild(li);
  }
});
