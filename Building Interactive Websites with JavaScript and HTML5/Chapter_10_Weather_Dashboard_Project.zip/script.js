const cityInput = document.getElementById('cityInput');
const searchBtn = document.getElementById('searchBtn');
const weatherSection = document.getElementById('weatherSection');
const favoritesList = document.getElementById('favoritesList');

const API_KEY = 'YOUR_API_KEY_HERE'; // Replace with your actual API key

async function fetchWeather(city) {
  const url = `https://api.openweathermap.org/data/2.5/weather?q=${encodeURIComponent(city)}&appid=${API_KEY}&units=metric`;

  try {
    const response = await fetch(url);
    if (!response.ok) {
      throw new Error('City not found');
    }
    const data = await response.json();
    return data;
  } catch (error) {
    throw error;
  }
}

function displayWeather(data) {
  weatherSection.innerHTML = `
    <div class="weather-card">
      <h3>${data.name}, ${data.sys.country}</h3>
      <p>Temperature: ${data.main.temp} °C</p>
      <p>Weather: ${data.weather[0].description}</p>
      <p>Humidity: ${data.main.humidity}%</p>
      <p>Wind speed: ${data.wind.speed} m/s</p>
      <button id="addFavoriteBtn">Add to Favorites</button>
    </div>
  `;

  const addFavoriteBtn = document.getElementById('addFavoriteBtn');
  addFavoriteBtn.addEventListener('click', () => addFavoriteCity(data.name));
}

searchBtn.addEventListener('click', async () => {
  const city = cityInput.value.trim();
  if (!city) {
    alert('Please enter a city name.');
    return;
  }
  try {
    weatherSection.innerHTML = 'Loading...';
    const weatherData = await fetchWeather(city);
    displayWeather(weatherData);
  } catch (error) {
    weatherSection.innerHTML = `<p style="color:red;">${error.message}</p>`;
  }
});

function getFavoriteCities() {
  const favorites = localStorage.getItem('favoriteCities');
  return favorites ? JSON.parse(favorites) : [];
}

function saveFavoriteCities(cities) {
  localStorage.setItem('favoriteCities', JSON.stringify(cities));
}

function addFavoriteCity(city) {
  let favorites = getFavoriteCities();
  if (!favorites.includes(city)) {
    favorites.push(city);
    saveFavoriteCities(favorites);
    renderFavorites();
    alert(`${city} added to favorites!`);
  } else {
    alert(`${city} is already in favorites.`);
  }
}

function renderFavorites() {
  const favorites = getFavoriteCities();
  favoritesList.innerHTML = '';

  favorites.forEach(city => {
    const li = document.createElement('li');
    li.textContent = city;
    li.addEventListener('click', async () => {
      cityInput.value = city;
      searchBtn.click();
    });
    favoritesList.appendChild(li);
  });
}

// Load favorites on page load
window.onload = () => {
  renderFavorites();
};