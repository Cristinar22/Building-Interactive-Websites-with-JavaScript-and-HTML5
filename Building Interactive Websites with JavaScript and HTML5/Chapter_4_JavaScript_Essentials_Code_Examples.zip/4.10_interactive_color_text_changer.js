// 4.10 HANDS-ON PROJECT: INTERACTIVE COLOR AND TEXT CHANGER

const displayText = document.getElementById('displayText');
const textInput = document.getElementById('textInput');
const colorInput = document.getElementById('colorInput');
const applyBtn = document.getElementById('applyBtn');

applyBtn.addEventListener('click', function() {
  if (textInput.value.trim() !== "") {
    displayText.textContent = textInput.value;
  }
  displayText.style.color = colorInput.value;
});
