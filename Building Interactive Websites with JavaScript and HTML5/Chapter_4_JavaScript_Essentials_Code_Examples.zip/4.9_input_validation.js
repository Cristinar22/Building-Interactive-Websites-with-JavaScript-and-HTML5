// 4.9 VALIDATING USER INPUT WITH JAVASCRIPT

const nameInput = document.getElementById('nameInput');
const submitBtn = document.getElementById('submitBtn');
const error = document.getElementById('error');

submitBtn.addEventListener('click', function() {
  if (nameInput.value.trim() === "") {
    error.textContent = "Name cannot be empty.";
  } else {
    error.textContent = "";
    alert("Form submitted successfully!");
  }
});
