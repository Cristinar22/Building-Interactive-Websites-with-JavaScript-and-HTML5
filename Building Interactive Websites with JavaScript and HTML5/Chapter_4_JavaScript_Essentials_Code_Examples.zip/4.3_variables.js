// 4.3 VARIABLES: CONTAINERS FOR INFORMATION

let name = "Alice";
const birthYear = 1995;

// Data Types
let greeting = "Hello World!";
let age = 30;
let isLoggedIn = false;
let undefinedVar;
let nullVar = null;

// Hands-On Example 2
let userName = "John";
const currentYear = 2025;

alert("Welcome, " + userName + "! The year is " + currentYear + ".");
