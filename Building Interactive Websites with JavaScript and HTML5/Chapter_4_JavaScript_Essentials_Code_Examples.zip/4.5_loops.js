// 4.5 LOOPS: DOING THINGS REPEATEDLY

// For Loop
for (let i = 1; i <= 5; i++) {
  console.log("This is loop number " + i);
}

// While Loop
let count = 1;
while (count <= 5) {
  console.log("Count is " + count);
  count++;
}

// Hands-On Example 4: Count Down with a Loop
for (let i = 10; i >= 1; i--) {
  console.log(i);
}
console.log("Happy New Year!");
