// 4.8 INTRODUCTION TO THE DOCUMENT OBJECT MODEL (DOM)

const list = document.getElementById('myList');
const addItemBtn = document.getElementById('addItemBtn');

addItemBtn.addEventListener('click', function() {
  const newItem = document.createElement('li');
  newItem.textContent = "New Item";
  list.appendChild(newItem);
});
