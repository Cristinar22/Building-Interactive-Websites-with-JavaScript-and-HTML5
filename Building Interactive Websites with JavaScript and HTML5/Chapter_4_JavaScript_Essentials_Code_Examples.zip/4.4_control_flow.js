// 4.4 CONTROL FLOW: MAKING DECISIONS WITH YOUR CODE

let temperature = 30;

if (temperature > 25) {
  alert("It's a hot day!");
} else {
  alert("It's not too hot today.");
}

let score = 85;

if (score >= 90) {
  alert("Grade: A");
} else if (score >= 80) {
  alert("Grade: B");
} else {
  alert("Keep trying!");
}

let day = "Monday";

switch(day) {
  case "Monday":
    alert("Start of the week!");
    break;
  case "Friday":
    alert("Almost weekend!");
    break;
  default:
    alert("Another day");
}

// Hands-On Example 3: Make Decisions Based on User Input

let userAge = prompt("How old are you?");

if (userAge >= 18) {
  alert("You are eligible to vote.");
} else {
  alert("Sorry, you are not eligible to vote yet.");
}
