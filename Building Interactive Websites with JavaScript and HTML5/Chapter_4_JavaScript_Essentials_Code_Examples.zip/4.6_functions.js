// 4.6 FUNCTIONS: REUSABLE BLOCKS OF CODE

function greet(name) {
  alert("Hello, " + name + "!");
}

greet("Alice");
greet("Bob");

function add(a, b) {
  return a + b;
}

let result = add(5, 7);
console.log(result);  // Output: 12

// Hands-On Example 5: Create and Use Functions
function calculateArea(width, height) {
  return width * height;
}

let area = calculateArea(10, 5);
alert("The area is " + area + " square units.");
