// 4.7 EVENTS: RESPONDING TO USER ACTIONS

const button = document.getElementById('clickMeBtn');

button.addEventListener('click', function() {
  alert("Button was clicked!");
});

// Hands-On Example 6: Change Text on Click
const text = document.getElementById('text');
const changeBtn = document.getElementById('changeTextBtn');

changeBtn.addEventListener('click', function() {
  text.textContent = "The text has been changed!";
});
